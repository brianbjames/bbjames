var localizedStrings = new Object;

localizedStrings["Hello, World!"] = "Hello, World!";
localizedStrings["Done"] = "Done";
localizedStrings["Feldman Says"] = "Feldman Says";

